syms x
I=int(cos(x)*cos(2*x),-pi/2,pi/2)
