x=@(s,t) 3*cos(s);
y=@(s,t) 2*sin(s);
z=@(s,t) t;
ezmesh(x,y,z)
