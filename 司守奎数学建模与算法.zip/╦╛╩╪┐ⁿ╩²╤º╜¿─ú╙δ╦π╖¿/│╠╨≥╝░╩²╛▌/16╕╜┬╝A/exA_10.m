[x,y,z,v] = flow;
isosurface(x,y,z,v);
